
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
using namespace std;

// Define course struct
struct Course {
    string courseNumber;
    string courseName;
    vector<string> prerequisites;
};

// Function prototypes
void loadDataStructure(string filename, vector<Course>& courses);
void printCourseList(const vector<Course>& courses);
void printCourse(const vector<Course>& courses, const string& courseNumber);
bool compareCourses(const Course& a, const Course& b);
string toUpper(string str);

int main() {
    vector<Course> courses;
    string userInput;
    int option = 0;

    cout << "Welcome to the course planner." << endl;

    while (option != 9) {
        // Display menu
        cout << "\n1. Load Data Structure." << endl;
        cout << "2. Print Course List." << endl;
        cout << "3. Print Course." << endl;
        cout << "9. Exit" << endl;
        cout << "\nWhat would you like to do? ";

        cin >> userInput;
        try {
            option = stoi(userInput);
        } catch (...) {
            option = -1;  // Handle invalid input
        }

        switch (option) {
            case 1: {
                string filename;
                cout << "\nEnter file name to load: ";
                cin >> filename;
                loadDataStructure(filename, courses);
                cout << "Courses loaded successfully!" << endl;
                break;
            }
            case 2:
                if (courses.empty()) {
                    cout << "\nPlease load data first (option 1)." << endl;
                } else {
                    printCourseList(courses);
                }
                break;
            case 3:
                if (courses.empty()) {
                    cout << "\nPlease load data first (option 1)." << endl;
                } else {
                    string searchNumber;
                    cout << "\nWhat course do you want to know about? ";
                    cin >> searchNumber;
                    printCourse(courses, toUpper(searchNumber));
                }
                break;
            case 9:
                cout << "\nThank you for using the course planner!" << endl;
                break;
            default:
                cout << "\n" << option << " is not a valid option." << endl;
        }
    }

    return 0;
}

// Load data from file into vector of courses
void loadDataStructure(string filename, vector<Course>& courses) {
    courses.clear();  // Clear previous data
    ifstream infile(filename);
    if (!infile) {
        cout << "Error: Could not open file " << filename << endl;
        return;
    }

    string line;
    while (getline(infile, line)) {
        Course course;
        stringstream ss(line);
        string item;

        // Get course number
        getline(ss, course.courseNumber, ',');
        course.courseNumber = toUpper(course.courseNumber);

        // Get course name
        getline(ss, course.courseName, ',');

        // Get prerequisites
        while (getline(ss, item, ',')) {
            course.prerequisites.push_back(toUpper(item));
        }

        courses.push_back(course);
    }

    infile.close();
    // Sort courses alphanumerically
    sort(courses.begin(), courses.end(), compareCourses);
}

// Sort comparison function
bool compareCourses(const Course& a, const Course& b) {
    return a.courseNumber < b.courseNumber;
}

// Print full course list
void printCourseList(const vector<Course>& courses) {
    cout << "\nHere is a sample schedule:\n" << endl;
    for (const auto& course : courses) {
        cout << course.courseNumber << ", " << course.courseName << endl;
    }
}

// Print single course details
void printCourse(const vector<Course>& courses, const string& courseNumber) {
    bool found = false;
    for (const auto& course : courses) {
        if (course.courseNumber == courseNumber) {
            found = true;
            cout << "\n" << course.courseNumber << ", " << course.courseName << endl;
            if (!course.prerequisites.empty()) {
                cout << "Prerequisites: ";
                for (size_t i = 0; i < course.prerequisites.size(); ++i) {
                    cout << course.prerequisites[i];
                    if (i < course.prerequisites.size() - 1)
                        cout << ", ";
                }
                cout << endl;
            } else {
                cout << "Prerequisites: None" << endl;
            }
            break;
        }
    }

    if (!found) {
        cout << "\nCourse not found: " << courseNumber << endl;
    }
}

// Helper to convert string to uppercase (case-insensitive search)
string toUpper(string str) {
    transform(str.begin(), str.end(), str.begin(), ::toupper);
    return str;
}
